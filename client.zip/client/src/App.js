import './App.css';
import BigTable from './components/BigTable';

function App() {
  return (
    <div>
      <BigTable/>
    </div>
  );
}

export default App;
